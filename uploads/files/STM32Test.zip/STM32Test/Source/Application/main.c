/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "stm32f10x_conf.h"

/* Private define ------------------------------------------------------------*/
#define LEDn                             2
#define LED3_PIN                         GPIO_Pin_9
#define LED3_GPIO_PORT                   GPIOC
#define LED3_GPIO_CLK                    RCC_APB2Periph_GPIOC

#define LED4_PIN                         GPIO_Pin_8
#define LED4_GPIO_PORT                   GPIOC
#define LED4_GPIO_CLK                    RCC_APB2Periph_GPIOC

/* Private typedef -----------------------------------------------------------*/
typedef enum {
	LED3 = 0, LED4 = 1
} Led_TypeDef;

/* Private variables ---------------------------------------------------------*/
GPIO_TypeDef* GPIO_PORT[LEDn] = { LED3_GPIO_PORT, LED4_GPIO_PORT };
const uint16_t GPIO_PIN[LEDn] = { LED3_PIN, LED4_PIN };
const uint32_t GPIO_CLK[LEDn] = { LED3_GPIO_CLK, LED4_GPIO_CLK };

/* Private function prototypes -----------------------------------------------*/
void Delay(volatile uint32_t nCount);

/* Private functions ---------------------------------------------------------*/
void LEDInit(Led_TypeDef Led) {
	GPIO_InitTypeDef GPIO_InitStructure;

	/* Enable the GPIO_LED Clock */
	RCC_APB2PeriphClockCmd(GPIO_CLK[Led], ENABLE);

	/* Configure the GPIO_LED pin */
	GPIO_InitStructure.GPIO_Pin = GPIO_PIN[Led];

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIO_PORT[Led], &GPIO_InitStructure);
}

void LEDOn(Led_TypeDef Led) {
	GPIO_PORT[Led]->BSRR = GPIO_PIN[Led];
}

void LEDOff(Led_TypeDef Led) {
	GPIO_PORT[Led]->BRR = GPIO_PIN[Led];
}
/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void) {
	/*!< At this stage the microcontroller clock setting is already configured,
	 this is done through SystemInit() function which is called from startup
	 file (startup_stm32f10x_xx.s) before to branch to application main.
	 To reconfigure the default setting of SystemInit() function, refer to
	 system_stm32f10x.c file
	 */

	/* Initialize Leds LD3 and LD4 mounted on STM32VLDISCOVERY board */
	LEDInit(LED3);
	LEDInit(LED4);

	while (1) {
		/* Turn on LD2 and LD3 */
		LEDOn(LED3);
		LEDOn(LED4);
		/* Insert delay */
		Delay(0xFFFF);
		/* Turn off LD3 and LD4 */
		LEDOff(LED3);
		LEDOff(LED4);
		/* Insert delay */
		Delay(0xAFFFF);
	}

	return 0; // Never Here
}

/**
 * @brief  Inserts a delay time.
 * @param  nCount: specifies the delay time length.
 * @retval None
 */
void Delay(volatile uint32_t nCount) {
	for (; nCount != 0; nCount--);
}

