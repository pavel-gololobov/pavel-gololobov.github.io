﻿using System;
using System.Threading;
using TBCPSerialPort;

namespace SmartAlarm {
    class CSmartAlarm {
        static CSerialPort _comPort = new CSerialPort();
        static bool _continue = false;
        Thread readThread = new Thread(ReadThread);

        const int DEFAULT_TIMEOUT = 500;

        public delegate void MessageProcessDelegate(byte[] Frame, int FrameLen);
        static MessageProcessDelegate _messageProcessDelegate;

        public void OpenPort(string PortName, MessageProcessDelegate messageDelegate) {
            _messageProcessDelegate = messageDelegate;
            
            _comPort.BaudRate = "19200";
            _comPort.Parity = "None";
            _comPort.DataBits = "8";
            _comPort.StopBits = "1";
            _comPort.PortName = PortName;
            _comPort.Timeout = 500;

            _comPort.OpenPort();
            _continue = true;
            readThread.Start();
        }

        public void ClosePort() {
            // Close Port
            _comPort.ClosePort();
            // Stop Processing Thread
            if (readThread.IsAlive) {
                _continue = false;
                readThread.Join();
            }
        }

        public static void ReadThread() {
            byte[] Frame = new byte[128];
            while (_continue) {
                int FrameLen = _comPort.Process(ref Frame);
                if (FrameLen > 0) {
                    _messageProcessDelegate(Frame, FrameLen);
                }
            }
        }

        public int RequestInfo() {
            return _comPort.Write(0x00, Commands.CMD_INFO, DEFAULT_TIMEOUT);
        }

        public int RequestTime() {
            return _comPort.Write(0x00, Commands.CMD_GET_TIME, DEFAULT_TIMEOUT);
        }

        public int SetTime(byte Day, byte Hrs, byte Mins) {
            byte[] Bytes = new byte[3];
            Bytes[0] = (byte)(Day - 1);
            Bytes[1] = Hrs;
            Bytes[2] = Mins;
            return _comPort.Write(0x00, Commands.CMD_SET_TIME, 3, Bytes, DEFAULT_TIMEOUT);
        }

        public int RequestStartTime() {
            return _comPort.Write(0x00, Commands.CMD_GET_START, DEFAULT_TIMEOUT);
        }

        public int SetStartTime(byte Hrs, byte Mins) {
            byte[] Bytes = new byte[2];
            Bytes[0] = Hrs;
            Bytes[1] = Mins;
            return _comPort.Write(0x00, Commands.CMD_SET_START, 2, Bytes, DEFAULT_TIMEOUT);
        }

        public int RequestAlarmTime() {
            return _comPort.Write(0x00, Commands.CMD_GET_ALARM, DEFAULT_TIMEOUT);
        }

        public int SetAlarmTime(byte Days, byte Hrs, byte Mins) {
            byte[] Bytes = new byte[3];
            Bytes[0] = Days;
            Bytes[1] = Hrs;
            Bytes[2] = Mins;
            return _comPort.Write(0x00, Commands.CMD_SET_ALARM, 3, Bytes, DEFAULT_TIMEOUT);
        }

    }
}
