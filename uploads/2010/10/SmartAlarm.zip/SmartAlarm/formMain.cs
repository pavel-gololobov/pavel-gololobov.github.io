﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using TBCPSerialPort;

namespace SmartAlarm {
    public partial class formMain : Form {

        CSmartAlarm _smartAlarm = new CSmartAlarm();

        public formMain() {
            InitializeComponent();
            UpdatePortList();
            UpdateControls(false);
        }

        void UpdateControls(bool IsOpen) {
            buttonOpenPort.Enabled = !IsOpen;
            buttonGet.Enabled = IsOpen;
            buttonSet.Enabled = IsOpen;
            buttonInfo.Enabled = IsOpen;
        }

        void UpdatePortList() {
            try {
                string[] lPorts = System.IO.Ports.SerialPort.GetPortNames();
                foreach(string sPort in lPorts) {
                    comboBoxSerialPort.Items.Add(sPort);
                }
            } catch(Exception Ex) {
                MessageBox.Show(Ex.Message);
            }
        }

        void UpdateInfoText(string Text) {
            if (textBoxInfo.InvokeRequired) {
                textBoxInfo.BeginInvoke(new MethodInvoker(delegate() {
                    UpdateInfoText(Text);
                }));
            } else {
                textBoxInfo.Text = Text;
            }
        }

        void UpdateTime(byte Day, byte Hrs, byte Mins, byte Secs) {
            if (timeHrs.InvokeRequired) {
                timeHrs.BeginInvoke(new MethodInvoker(delegate() {
                    UpdateTime(Day, Hrs, Mins, Secs);
                }));
            } else {
                timeDay.Value = Day + 1;
                timeHrs.Value = Hrs;
                timeMins.Value = Mins;
                timeSecs.Value = Secs;
            }
        }

        void UpdateStart(byte Hrs, byte Mins) {
            if (timeStartHrs.InvokeRequired) {
                timeStartHrs.BeginInvoke(new MethodInvoker(delegate() {
                    UpdateStart(Hrs, Mins);
                }));
            } else {
                timeStartHrs.Value = Hrs;
                timeStartMins.Value = Mins;
            }
        }

        void UpdateAlarm(byte Days, byte Hrs, byte Mins) {
            if (timeAlarmHrs.InvokeRequired) {
                timeAlarmHrs.BeginInvoke(new MethodInvoker(delegate() {
                    UpdateAlarm(Days, Hrs, Mins);
                }));
            } else {
                checkBox1.Checked = ((Days & 0x01) > 0);
                checkBox2.Checked = ((Days & 0x02) > 0);
                checkBox3.Checked = ((Days & 0x04) > 0);
                checkBox4.Checked = ((Days & 0x08) > 0);
                checkBox5.Checked = ((Days & 0x10) > 0);
                checkBox6.Checked = ((Days & 0x20) > 0);
                checkBox7.Checked = ((Days & 0x40) > 0);
                timeAlarmHrs.Value = Hrs;
                timeAlarmMins.Value = Mins;
            }
        }

        public void MessageProcess(byte[] Frame, int FrameLen) {
            try {
                byte Command = Frame[1];
                switch (Command) {
                    case Commands.CMD_INFO:
                        UpdateInfoText(Encoding.ASCII.GetString(Frame, 3, FrameLen));
                        break;
                    case Commands.CMD_GET_TIME:
                        UpdateTime(Frame[3], Frame[4], Frame[5], Frame[6]);
                        break;
                    case Commands.CMD_GET_START:
                        UpdateStart(Frame[3], Frame[4]);
                        break;
                    case Commands.CMD_GET_ALARM:
                        UpdateAlarm(Frame[3], Frame[4], Frame[5]);
                        break;
                }
            } catch (Exception Ex) {
                MessageBox.Show(Ex.Message);
            }
        }

        private void buttonOpenPort_Click(object sender, EventArgs e) {
            try {
                if (comboBoxSerialPort.SelectedIndex >= 0) {
                    _smartAlarm.OpenPort(comboBoxSerialPort.SelectedItem.ToString(), MessageProcess);
                    UpdateControls(true);
                } else {
                    MessageBox.Show("Please select Serial Port");
                }
            } catch (Exception Ex) {
                MessageBox.Show(Ex.Message);
            }
        }

        private void OnClosing(object sender, FormClosingEventArgs e) {
            try {
                _smartAlarm.ClosePort();
            } catch (Exception Ex) {
                MessageBox.Show(Ex.Message);
            }
        }

        private void buttonGet_Click(object sender, EventArgs e) {
            try {
                int Ret = 0;
                Ret += _smartAlarm.RequestTime();
                Ret += _smartAlarm.RequestStartTime();
                Ret += _smartAlarm.RequestAlarmTime();
                if (Ret < 0) {
                    MessageBox.Show("Push The Button");
                    UpdateInfoText("Error");
                    return;
                }
                UpdateInfoText("OK");
            } catch (Exception Ex) {
                MessageBox.Show(Ex.Message);
            }
        }

        private void buttonSet_Click(object sender, EventArgs e) {
            try {
                byte Days = 0;
                if (checkBox1.Checked) Days |= 0x01;
                if (checkBox2.Checked) Days |= 0x02;
                if (checkBox3.Checked) Days |= 0x04;
                if (checkBox4.Checked) Days |= 0x08;
                if (checkBox5.Checked) Days |= 0x10;
                if (checkBox6.Checked) Days |= 0x20;
                if (checkBox7.Checked) Days |= 0x40;

                int Ret = 0;
                Ret += _smartAlarm.SetTime((byte)timeDay.Value, (byte)timeHrs.Value, (byte)timeMins.Value);
                Ret += _smartAlarm.SetStartTime((byte)timeStartHrs.Value, (byte)timeStartMins.Value);
                Ret += _smartAlarm.SetAlarmTime(Days, (byte)timeAlarmHrs.Value, (byte)timeAlarmMins.Value);
                if (Ret < 0) {
                    MessageBox.Show("Push The Button");
                    UpdateInfoText("Error");
                    return;
                }
                UpdateInfoText("OK");
            } catch (Exception Ex) {
                MessageBox.Show(Ex.Message);
            }
        }

        private void buttonInfo_Click(object sender, EventArgs e) {
            try {
                _smartAlarm.RequestInfo();
            } catch (Exception Ex) {
                MessageBox.Show(Ex.Message);
            }
        }
    }
}
