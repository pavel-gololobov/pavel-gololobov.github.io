﻿namespace SmartAlarm {
    partial class formMain {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formMain));
            this.comboBoxSerialPort = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonOpenPort = new System.Windows.Forms.Button();
            this.groupBoxDays = new System.Windows.Forms.GroupBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.timeHrs = new System.Windows.Forms.NumericUpDown();
            this.timeMins = new System.Windows.Forms.NumericUpDown();
            this.timeSecs = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBoxTime = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.timeDay = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.timeStartMins = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.timeStartHrs = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.timeAlarmMins = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.timeAlarmHrs = new System.Windows.Forms.NumericUpDown();
            this.buttonGet = new System.Windows.Forms.Button();
            this.buttonSet = new System.Windows.Forms.Button();
            this.textBoxInfo = new System.Windows.Forms.TextBox();
            this.buttonInfo = new System.Windows.Forms.Button();
            this.groupBoxDays.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.timeHrs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.timeMins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.timeSecs)).BeginInit();
            this.groupBoxTime.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.timeDay)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.timeStartMins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.timeStartHrs)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.timeAlarmMins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.timeAlarmHrs)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxSerialPort
            // 
            this.comboBoxSerialPort.FormattingEnabled = true;
            this.comboBoxSerialPort.Location = new System.Drawing.Point(74, 12);
            this.comboBoxSerialPort.Name = "comboBoxSerialPort";
            this.comboBoxSerialPort.Size = new System.Drawing.Size(96, 21);
            this.comboBoxSerialPort.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "COM Port:";
            // 
            // buttonOpenPort
            // 
            this.buttonOpenPort.Location = new System.Drawing.Point(176, 12);
            this.buttonOpenPort.Name = "buttonOpenPort";
            this.buttonOpenPort.Size = new System.Drawing.Size(75, 23);
            this.buttonOpenPort.TabIndex = 2;
            this.buttonOpenPort.Text = "Open";
            this.buttonOpenPort.UseVisualStyleBackColor = true;
            this.buttonOpenPort.Click += new System.EventHandler(this.buttonOpenPort_Click);
            // 
            // groupBoxDays
            // 
            this.groupBoxDays.Controls.Add(this.checkBox7);
            this.groupBoxDays.Controls.Add(this.checkBox6);
            this.groupBoxDays.Controls.Add(this.checkBox5);
            this.groupBoxDays.Controls.Add(this.checkBox4);
            this.groupBoxDays.Controls.Add(this.checkBox3);
            this.groupBoxDays.Controls.Add(this.checkBox2);
            this.groupBoxDays.Controls.Add(this.checkBox1);
            this.groupBoxDays.Location = new System.Drawing.Point(12, 67);
            this.groupBoxDays.Name = "groupBoxDays";
            this.groupBoxDays.Size = new System.Drawing.Size(96, 188);
            this.groupBoxDays.TabIndex = 3;
            this.groupBoxDays.TabStop = false;
            this.groupBoxDays.Text = "Days";
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(6, 157);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(62, 17);
            this.checkBox7.TabIndex = 6;
            this.checkBox7.Text = "Sunday";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(6, 134);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(68, 17);
            this.checkBox6.TabIndex = 5;
            this.checkBox6.Text = "Saturday";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(6, 111);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(54, 17);
            this.checkBox5.TabIndex = 4;
            this.checkBox5.Text = "Friday";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(6, 88);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(70, 17);
            this.checkBox4.TabIndex = 3;
            this.checkBox4.Text = "Thursday";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(6, 65);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(83, 17);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "Wednesday";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(6, 42);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(67, 17);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "Tuesday";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(6, 19);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(64, 17);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "Monday";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // timeHrs
            // 
            this.timeHrs.Location = new System.Drawing.Point(6, 18);
            this.timeHrs.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.timeHrs.Name = "timeHrs";
            this.timeHrs.Size = new System.Drawing.Size(48, 20);
            this.timeHrs.TabIndex = 7;
            // 
            // timeMins
            // 
            this.timeMins.Location = new System.Drawing.Point(76, 18);
            this.timeMins.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.timeMins.Name = "timeMins";
            this.timeMins.Size = new System.Drawing.Size(48, 20);
            this.timeMins.TabIndex = 8;
            // 
            // timeSecs
            // 
            this.timeSecs.Location = new System.Drawing.Point(146, 18);
            this.timeSecs.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.timeSecs.Name = "timeSecs";
            this.timeSecs.Size = new System.Drawing.Size(48, 20);
            this.timeSecs.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(60, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(10, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = ":";
            // 
            // groupBoxTime
            // 
            this.groupBoxTime.Controls.Add(this.label6);
            this.groupBoxTime.Controls.Add(this.timeDay);
            this.groupBoxTime.Controls.Add(this.label2);
            this.groupBoxTime.Controls.Add(this.label4);
            this.groupBoxTime.Controls.Add(this.timeHrs);
            this.groupBoxTime.Controls.Add(this.timeMins);
            this.groupBoxTime.Controls.Add(this.timeSecs);
            this.groupBoxTime.Location = new System.Drawing.Point(114, 67);
            this.groupBoxTime.Name = "groupBoxTime";
            this.groupBoxTime.Size = new System.Drawing.Size(295, 49);
            this.groupBoxTime.TabIndex = 13;
            this.groupBoxTime.TabStop = false;
            this.groupBoxTime.Text = "Time";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(209, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Day";
            // 
            // timeDay
            // 
            this.timeDay.Location = new System.Drawing.Point(241, 18);
            this.timeDay.Maximum = new decimal(new int[] {
            7,
            0,
            0,
            0});
            this.timeDay.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.timeDay.Name = "timeDay";
            this.timeDay.Size = new System.Drawing.Size(48, 20);
            this.timeDay.TabIndex = 14;
            this.timeDay.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(130, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(10, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = ":";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.timeStartMins);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.timeStartHrs);
            this.groupBox1.Location = new System.Drawing.Point(114, 122);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(295, 49);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Start Time";
            // 
            // timeStartMins
            // 
            this.timeStartMins.Location = new System.Drawing.Point(76, 19);
            this.timeStartMins.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.timeStartMins.Name = "timeStartMins";
            this.timeStartMins.Size = new System.Drawing.Size(48, 20);
            this.timeStartMins.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(10, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = ":";
            // 
            // timeStartHrs
            // 
            this.timeStartHrs.Location = new System.Drawing.Point(6, 19);
            this.timeStartHrs.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.timeStartHrs.Name = "timeStartHrs";
            this.timeStartHrs.Size = new System.Drawing.Size(48, 20);
            this.timeStartHrs.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.timeAlarmMins);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.timeAlarmHrs);
            this.groupBox2.Location = new System.Drawing.Point(114, 177);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(295, 49);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Alarm Time";
            // 
            // timeAlarmMins
            // 
            this.timeAlarmMins.Location = new System.Drawing.Point(76, 19);
            this.timeAlarmMins.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.timeAlarmMins.Name = "timeAlarmMins";
            this.timeAlarmMins.Size = new System.Drawing.Size(48, 20);
            this.timeAlarmMins.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(59, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(10, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = ":";
            // 
            // timeAlarmHrs
            // 
            this.timeAlarmHrs.Location = new System.Drawing.Point(6, 19);
            this.timeAlarmHrs.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.timeAlarmHrs.Name = "timeAlarmHrs";
            this.timeAlarmHrs.Size = new System.Drawing.Size(48, 20);
            this.timeAlarmHrs.TabIndex = 0;
            // 
            // buttonGet
            // 
            this.buttonGet.Location = new System.Drawing.Point(190, 232);
            this.buttonGet.Name = "buttonGet";
            this.buttonGet.Size = new System.Drawing.Size(75, 23);
            this.buttonGet.TabIndex = 16;
            this.buttonGet.Text = "Get";
            this.buttonGet.UseVisualStyleBackColor = true;
            this.buttonGet.Click += new System.EventHandler(this.buttonGet_Click);
            // 
            // buttonSet
            // 
            this.buttonSet.Location = new System.Drawing.Point(274, 232);
            this.buttonSet.Name = "buttonSet";
            this.buttonSet.Size = new System.Drawing.Size(75, 23);
            this.buttonSet.TabIndex = 17;
            this.buttonSet.Text = "Set";
            this.buttonSet.UseVisualStyleBackColor = true;
            this.buttonSet.Click += new System.EventHandler(this.buttonSet_Click);
            // 
            // textBoxInfo
            // 
            this.textBoxInfo.Location = new System.Drawing.Point(12, 41);
            this.textBoxInfo.Name = "textBoxInfo";
            this.textBoxInfo.ReadOnly = true;
            this.textBoxInfo.Size = new System.Drawing.Size(397, 20);
            this.textBoxInfo.TabIndex = 18;
            // 
            // buttonInfo
            // 
            this.buttonInfo.Location = new System.Drawing.Point(334, 12);
            this.buttonInfo.Name = "buttonInfo";
            this.buttonInfo.Size = new System.Drawing.Size(75, 23);
            this.buttonInfo.TabIndex = 19;
            this.buttonInfo.Text = "Info";
            this.buttonInfo.UseVisualStyleBackColor = true;
            this.buttonInfo.Click += new System.EventHandler(this.buttonInfo_Click);
            // 
            // formMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(421, 267);
            this.Controls.Add(this.buttonInfo);
            this.Controls.Add(this.textBoxInfo);
            this.Controls.Add(this.buttonSet);
            this.Controls.Add(this.buttonGet);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBoxTime);
            this.Controls.Add(this.groupBoxDays);
            this.Controls.Add(this.buttonOpenPort);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxSerialPort);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formMain";
            this.Text = "Smart Alarm 1.0";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnClosing);
            this.groupBoxDays.ResumeLayout(false);
            this.groupBoxDays.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.timeHrs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.timeMins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.timeSecs)).EndInit();
            this.groupBoxTime.ResumeLayout(false);
            this.groupBoxTime.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.timeDay)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.timeStartMins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.timeStartHrs)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.timeAlarmMins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.timeAlarmHrs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxSerialPort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonOpenPort;
        private System.Windows.Forms.GroupBox groupBoxDays;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.NumericUpDown timeHrs;
        private System.Windows.Forms.NumericUpDown timeMins;
        private System.Windows.Forms.NumericUpDown timeSecs;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBoxTime;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown timeStartMins;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown timeStartHrs;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown timeAlarmMins;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown timeAlarmHrs;
        private System.Windows.Forms.Button buttonGet;
        private System.Windows.Forms.Button buttonSet;
        private System.Windows.Forms.TextBox textBoxInfo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown timeDay;
        private System.Windows.Forms.Button buttonInfo;

    }
}

