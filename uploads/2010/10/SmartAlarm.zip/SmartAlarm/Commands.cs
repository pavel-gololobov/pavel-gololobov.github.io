﻿namespace SmartAlarm {
    public struct Commands {
        /*
         * Standart Commands
         */
        public const byte CMD_NOP =         0x00;		// NOP
        public const byte CMD_ERR =         0x01;		// RX Error
        public const byte CMD_ECHO =        0x02;		// Echo
        public const byte CMD_INFO =        0x03;		// Info
        public const byte CMD_SETADDR =     0x04;		// Set Address
        public const byte CMD_GETADDR =     0x05;		// Get Address

        /*
         * Smart Alarm Commands
         */
        public const byte CMD_GET_TIME =	0x10;
        public const byte CMD_SET_TIME = 	0x11;
        public const byte CMD_GET_ALARM =	0x20;
        public const byte CMD_SET_ALARM =	0x21;
        public const byte CMD_GET_START =	0x22;
        public const byte CMD_SET_START =	0x23;
        public const byte CMD_GET_LOG =     0x30;
    }
}