/*
 * uart.h
 *
 *  Created on: 02.05.2010
 *      Author: Pavel V. Gololobov
 */

#ifndef UART_H_
#define UART_H_

#include <stdint.h>

/*
 * Interface
 */
void UARTA0_Init(void);

#endif /* UART_H_ */
