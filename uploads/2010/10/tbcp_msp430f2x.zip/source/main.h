/*
 * main.h
 *
 *  Created on: 07.05.2010
 *      Author: Pavel V. Gololobov
 */

#ifndef MAIN_H_
#define MAIN_H_


#endif /* MAIN_H_ */
