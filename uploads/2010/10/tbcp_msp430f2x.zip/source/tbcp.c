/*
 * tbcp.c
 *
 *  Created on: 03.06.2010
 *      Author: Pavel V. Gololobov
 */

#include <io430x26x.h>
#include <stdint.h>
#include "crc8.h"
#include "commands.h"
#include "tbcp.h"

#define ASCII_CR     '\r'
#define ASCII_LF     '\n'
#define ASCII_SOF	 ':'

#define TBCP_BROADCAST	0x00

typedef enum {
    STATE_RX_IDLE,              /* Receiver is in idle state. */
    STATE_RX_RCV,               /* Frame is beeing received. */
    STATE_RX_WAIT_EOF           /* Wait for End of Frame. */
} eTBCPRcvState;

typedef enum {
    STATE_TX_IDLE,              /* Transmitter is in idle state. */
    STATE_TX_START,             /* Starting transmission (':' sent). */
    STATE_TX_DATA,              /* Sending of data (Address, Data, LRC). */
    STATE_TX_END               /* End of transmission. */
} eTBCPSndState;

typedef enum {
    BYTE_HIGH_NIBBLE,           /* Character for high nibble of byte. */
    BYTE_LOW_NIBBLE             /* Character for low nibble of byte. */
} eTBCPBytePos;

/*
 * States
 */
volatile eTBCPRcvState eRcvState;
volatile eTBCPSndState eSndState;
volatile eTBCPBytePos eBytePos;

/*
 * Data Buffers
 */
uint8_t RcvFrame[TBCP_FRAME_SIZE];
uint8_t SndFrame[TBCP_FRAME_SIZE];
volatile uint8_t ucRcvDataPos;
volatile uint8_t ucSndDataPos;
volatile uint8_t ucSndDataCount;

/*
 * Flags
 */
volatile uint8_t ucFrameReceived;

uint8_t ucSlaveAddress;

/*
 * Text to Integer
 * Integer to Text
 */
static uint8_t CHAR2BIN(uint8_t ucCharacter);
static uint8_t BIN2CHAR(uint8_t ucByte);

/*
 * Init Protocol Stack
 */
eTBCPErrorCode TBCP_Init(uint8_t ucAddress) {
	ucSlaveAddress = ucAddress;

	eRcvState = STATE_RX_IDLE;
	eSndState = STATE_TX_IDLE;

	ucRcvDataPos = 0;
	ucSndDataPos = 0;
	ucSndDataCount = 0;

	ucFrameReceived = 0;

	return TBCP_ENOERR;
}

/*
 * RX Interrupt
 */
#pragma vector=USCIAB0RX_VECTOR
__interrupt void USCI0RX_ISR(void) {
	uint8_t ucByte;
	uint8_t ucResult;

	/* Read Data */
	ucByte = UCA0RXBUF;

	/* Frame already received? Ignoring any new data */
	if(ucFrameReceived) {
		return;
	}
	/* Start Of Frame Received */
	if(ucByte == ASCII_SOF) {
		/* Reset the input buffers to store the frame. */
		ucRcvDataPos = 0;
		eBytePos = BYTE_HIGH_NIBBLE;
		eRcvState = STATE_RX_RCV;
		return;
	}
	switch(eRcvState) {
	case STATE_RX_RCV: {
		if(ucByte == ASCII_CR) {
			eRcvState = STATE_RX_WAIT_EOF;
		} else {
			ucResult = CHAR2BIN(ucByte);
			switch(eBytePos) {
			case BYTE_HIGH_NIBBLE: {
				if(ucRcvDataPos < TBCP_FRAME_SIZE) {
					RcvFrame[ucRcvDataPos] = (uint8_t)(ucResult << 4);
					eBytePos = BYTE_LOW_NIBBLE;
					break;
				} else {
					eRcvState = STATE_RX_IDLE;
				}
				break;
			}
			case BYTE_LOW_NIBBLE: {
				RcvFrame[ucRcvDataPos] |= (uint8_t)(ucResult & 0x0F);
				ucRcvDataPos++;
				eBytePos = BYTE_HIGH_NIBBLE;
				break;
			}
			}
		}
		break;
	}
	case STATE_RX_WAIT_EOF: {
		if(ucByte == ASCII_LF) {
			/* Receiver is again in idle state. */
			eRcvState = STATE_RX_IDLE;
			/* Set global Flag */
			ucFrameReceived = 1;
		} else {
			/* Frame is not OK. Delete frame. */
			eRcvState = STATE_RX_IDLE;
		}
		break;
	}
	}
}

#pragma vector=USCIAB0TX_VECTOR
__interrupt void USCI0TX_ISR(void) {
    uint8_t ucByte;
    switch(eSndState) {
        /* Start of transmission. The start of a frame is defined by sending
         * the character ':'. */
    case STATE_TX_START: {
        ucByte = ASCII_SOF;
        UCA0TXBUF = ucByte;
        eSndState = STATE_TX_DATA;
        eBytePos = BYTE_HIGH_NIBBLE;
        break;
    }
        /* Send the data block. Each data byte is encoded as a character hex
         * stream with the high nibble sent first and the low nibble sent
         * last. If all data bytes are exhausted we send a '\r' character
         * to end the transmission. */
    case STATE_TX_DATA: {
        if(ucSndDataCount > 0) {
            switch(eBytePos) {
            case BYTE_HIGH_NIBBLE: {
                ucByte = BIN2CHAR(SndFrame[ucSndDataPos] >> 4);
                UCA0TXBUF = ucByte;
                eBytePos = BYTE_LOW_NIBBLE;
                break;
            }
            case BYTE_LOW_NIBBLE: {
                ucByte = BIN2CHAR(SndFrame[ucSndDataPos] & 0x0F);
                UCA0TXBUF = ucByte;
                ucSndDataPos++;
                ucSndDataCount--;
                eBytePos = BYTE_HIGH_NIBBLE;
                break;
            }
            }
        } else {
        	UCA0TXBUF = ASCII_CR;
            eSndState = STATE_TX_END;
        }
        break;
    }
    /* Finish the frame by sending a LF character. */
    case STATE_TX_END: {
    	UCA0TXBUF = ASCII_LF;
        eSndState = STATE_TX_IDLE;
        IE2 &= ~UCA0TXIE;
        break;
    }
	}
}

/*
 * Message Handle
 */
eTBCPErrorCode Process() {
	/* Frame Received */
	if(ucFrameReceived) {
		/* Handle Message */
		uint8_t ucAddress = RcvFrame[TBCP_ADDR_INDEX];
		uint8_t ucCommand = RcvFrame[TBCP_CMD_INDEX];
		uint8_t ucLength = RcvFrame[TBCP_LEN_INDEX];
		/* Check Array Index */
		if(ucLength > TBCP_MAX_DATA_LENGTH) {
			/* Error! Reset Message */
			ucFrameReceived = 0;
			return TBCP_EOVERFLOW;
		}
		uint8_t ucRxCRC = RcvFrame[TBCP_DATA_INDEX + ucLength];
		uint8_t ucCRC = TBCP_CRC8(RcvFrame, TBCP_DATA_INDEX + ucLength);

		/* Check CRC */
		if(ucRxCRC == ucCRC) {
			/* Is Message to this device? */
			if((ucAddress == ucSlaveAddress) || (ucAddress == TBCP_BROADCAST)) {
				Command_Exe(ucCommand);
			}
		}
		/* Reset Message */
		ucFrameReceived = 0;
	}
	return TBCP_ENOERR;
}

/*
 * Send Message
 */
eTBCPErrorCode Send(uint8_t ucCommand, uint8_t ucLength) {
	/* Buffer Overflow? */
	if(ucLength > TBCP_MAX_DATA_LENGTH) {
		return TBCP_EINVAL;
	}
	SndFrame[TBCP_ADDR_INDEX] = ucSlaveAddress;
	SndFrame[TBCP_CMD_INDEX] = ucCommand;
	SndFrame[TBCP_LEN_INDEX] = ucLength;
	SndFrame[TBCP_DATA_INDEX + ucLength] = TBCP_CRC8(SndFrame, TBCP_DATA_INDEX + ucLength);

	ucSndDataPos = 0;
	ucSndDataCount = ucLength + 4; // Addr + Cmd + Len + CRC

	eSndState = STATE_TX_START;
	IE2 |= UCA0TXIE;

	return TBCP_ENOERR;
}

/*
 * Reply without data
 */
eTBCPErrorCode Reply(uint8_t ucCommand, uint8_t ucErrorCode) {
	SndFrame[TBCP_DATA_INDEX] = ucErrorCode;
	return Send(ucCommand, 1);
}

/*
 * Convert Character to BIN
 */
static uint8_t CHAR2BIN(uint8_t ucCharacter) {
    if((ucCharacter >= '0') && (ucCharacter <= '9'))
        return (uint8_t)(ucCharacter - '0');
    else if((ucCharacter >= 'A') && (ucCharacter <= 'F'))
        return (uint8_t)(ucCharacter - 'A' + 0x0A);
	return 0xFF;
}

/*
 * Convert BIN to Character
 */
static uint8_t BIN2CHAR(uint8_t ucByte) {
    if(ucByte <= 0x09)
        return (uint8_t)('0' + ucByte);
    else if((ucByte >= 0x0A) && (ucByte <= 0x0F))
        return (uint8_t)(ucByte - 0x0A + 'A');
	return '0';
}


