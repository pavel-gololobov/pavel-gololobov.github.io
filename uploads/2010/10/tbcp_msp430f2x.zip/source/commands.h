/*
 * commands.h
 *
 *  Created on: 03.05.2010
 *      Author: Pavel V. Gololobov
 */

#ifndef COMMANDS_H_
#define COMMANDS_H_

/*
 * BuildIn Commands
 */
#define CMD_NOP			0x00		// NOP
#define CMD_ERR			0x01		// RX Error
#define CMD_ECHO		0x02		// Echo
#define CMD_INFO		0x03		// Info
#define CMD_SETADDR		0x04		// Set Address
#define CMD_GETADDR		0x05		// Get Address

/*
 * Exe
 */
void Command_Exe(uint8_t ucCommand);

#endif /* COMMANDS_H_ */
