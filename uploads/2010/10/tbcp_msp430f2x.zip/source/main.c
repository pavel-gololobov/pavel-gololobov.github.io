/*
 * main.c
 *
 *  Created on: 02.05.2010
 *      Author: Pavel V. Gololobov
 */

#include <io430x26x.h>
#include <stdio.h>
#include <stdint.h>
#include <intrinsics.h>

#include "uart.h"
#include "tbcp.h"
#include "main.h"

// target DCO = DELTA*(4096) = 11.0592MHz
#define DELTA 2700
void Set_DCO(void);

int main(void) {
	// Stop watchdog timer to prevent time out reset
	WDTCTL = WDTPW + WDTHOLD;

	Set_DCO();
	UARTA0_Init();
	TBCP_Init(0x00);

	__enable_interrupt();

	while(1) {
		Process();
	}

	return 0;
}

/*
 * Set DCO to selected frequency
 */
void Set_DCO(void) {
	unsigned int Compare, Oldcapture = 0;

	BCSCTL1 |= DIVA_3;                        // ACLK= LFXT1CLK/8 = 4096Hz
	TACCTL2 = CM_1 + CCIS_1 + CAP;            // CAP, ACLK
	TACTL = TASSEL_2 + MC_2 + TACLR;          // SMCLK, cont-mode, clear

	while (1) {
		while (!(CCIFG & TACCTL2));           // Wait until capture occured
		TACCTL2 &= ~CCIFG;                    // Capture occured, clear flag
		Compare = TACCR2;                     // Get current captured SMCLK
		Compare = Compare - Oldcapture;       // SMCLK difference
		Oldcapture = TACCR2;                  // Save current captured SMCLK

		if (DELTA == Compare)
			break;                            // If equal, leave "while(1)"
		else if (DELTA < Compare) {
			DCOCTL--;                         // DCO is too fast, slow it down
			if (DCOCTL == 0xFF)               // Did DCO roll under?
				if (BCSCTL1 & 0x0f)
					BCSCTL1--;                // Select lower RSEL
		} else {
			DCOCTL++;                         // DCO is too slow, speed it up
			if (DCOCTL == 0x00)               // Did DCO roll over?
				if ((BCSCTL1 & 0x0f) != 0x0f)
					BCSCTL1++;                // Sel higher RSEL
		}
	}
	TACCTL2 = 0;                              // Stop TACCR2
	TACTL = 0;                                // Stop Timer_A
	BCSCTL1 &= ~DIVA_3;                       // ACLK = LFXT1CLK = 32.768KHz
}
