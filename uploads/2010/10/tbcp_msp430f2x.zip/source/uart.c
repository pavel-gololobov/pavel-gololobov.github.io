/*
 * uart.c
 *
 *  Created on: 02.05.2010
 *      Author: Pavel V. Gololobov
 */

#include <io430x26x.h>
#include <stdio.h>
#include <stdint.h>
#include "uart.h"

/*
 * Init UARTA0 Port
 */
void UARTA0_Init(void) {
	P3OUT &= ~(BIT4 + BIT5);
	P3SEL |= BIT4 + BIT5;			// Enable UARTA0 pins

	UCA0CTL1 |= UCSSEL_2;			// SMCLK

	UCA0BR0 = 0x40;
	UCA0BR1 = 0x02;
	UCA0MCTL = 0;					// uartA0 11059200Hz 19200bps

	UCA0CTL1 &= ~UCSWRST;			// Initialize

	IE2 |= UCA0RXIE;				// Enable USCI_A0 RX interrupt
}
