/*
 * commands.c
 *
 *  Created on: 03.05.2010
 *      Author: Pavel V. Gololobov
 */

#include <stdint.h>
#include "tbcp.h"
#include "commands.h"

/*
 * Device Info String
 */
const uint8_t Info[] = {"Device Info\0"};

/*
 * Error
 */
void CmdErr() {
	Reply(CMD_ERR, TBCP_EIO);
}

/*
 * Echo
 */
void CmdEcho() {
	uint16_t i;
	for(i = 0; i < RcvFrame[TBCP_LEN_INDEX] && i < TBCP_FRAME_SIZE; i++)
		SndFrame[i + TBCP_DATA_INDEX] = RcvFrame[i + TBCP_DATA_INDEX];
	Send(RcvFrame[TBCP_CMD_INDEX], RcvFrame[TBCP_LEN_INDEX]);
}

/*
 * Get Device Info
 */
void CmdInfo() {
	uint16_t i;
	uint8_t ch = 1;
	for(i = 0; i < TBCP_FRAME_SIZE && ch; i++)
		ch = SndFrame[i + TBCP_DATA_INDEX] = Info[i];
	Send(RcvFrame[TBCP_CMD_INDEX], i);
}

/*
 * Commant Not Implemented
 */
void CmdNotImplemented() {
	Reply(CMD_ERR, TBCP_ENOTIMPL);
}

/*
 * Commands Switch
 */
void Command_Exe(uint8_t ucCommand) {
	switch(ucCommand) {
		case CMD_NOP: {
			break;
		}
		case CMD_ERR: {
			CmdErr();
			break;
		}
		case CMD_ECHO: {
			CmdEcho();
			break;
		}
		case CMD_INFO: {
			CmdInfo();
			break;
		}
		default: {
			CmdNotImplemented();
			break;
		}
	}
}

