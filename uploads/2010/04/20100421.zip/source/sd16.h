/*
 * sd16.h
 *
 *  Created on: Apr 15, 2010
 *      Author: Pavel V. Gololobov
 */

#ifndef SD16_H_
#define SD16_H_

/*
 * Init 16-Bit ADC
 */
void SD16Init() {
	volatile uint16_t i;							// Use volatile to prevent removal

	SD16CTL = SD16REFON + SD16SSEL_1 + SD16XDIV_2;	// 1.2V ref, SMCLK, /48
	SD16CCTL0 = SD16SNGL + SD16UNI + SD16IE;			//SD16SNGL
													// Single conv, 256OSR, unipolar,
													// enable interrupt

	SD16INCTL0 = SD16INCH_0 + SD16GAIN_16;			// Set channel A0+/-, GAIN x32
	SD16AE = SD16AE0 + SD16AE1;						// P1.0 A0+, P1.1 Vss

	for (i = 0; i < 0x3600; i++);						// Delay for 1.2V ref startup
}

#endif /* SD16_H_ */
