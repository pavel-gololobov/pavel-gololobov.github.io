/*
 * main.c
 *
 *  Created on: Apr 14, 2010
 *      Author: Pavel V. Gololobov
 * 
 *  Version 1.0
 */

#include <msp430x20x3.h>
#include <intrinsics.h>
#include <stdint.h>

#include "main.h"
#include "adc_tables.h"
#include "timer_a.h"
#include "clock.h"
#include "sd16.h"

/* ACD Result Accumulator 32-bit */
static uint32_t ChA0Acc = 0x00;
static uint32_t ChA1Acc = 0x00;
static uint32_t ChA2Acc = 0x00;
static uint32_t ChA6Acc = 0x00;

/* Settings */
static uint16_t SetTemp = 0;		// 1..500
static uint16_t SetMotor = 0;		// 1..100

/* Actual Value */
static uint16_t ActualTemp = 0;

/* Global Flags */
static uint16_t ADCReady = 0;
static uint16_t Dock = 1;

/* Counters */
static uint16_t Channel = 0;
static uint16_t Acc = 0;

/* Key Accumulator */
static uint16_t DockAcc = 0;

/* Func Prototypes */
void IOInit();
void ReadKey();
uint16_t GetTemp(uint16_t, uint16_t);
uint16_t GetSetTemp(uint16_t);
uint16_t GetSetMotor(uint16_t);
void Regulator();

/*
 * Main
 */
int main( void ) {
	// Stop watchdog timer to prevent time out reset
	WDTCTL = WDTPW + WDTHOLD;

	ClockInit();
	SD16Init();
	TAInit();
	IOInit();

	__enable_interrupt();

	WDTCTL = WDT_ARST_1000; 				// WDT Timer, 1000 ms
	SD16CCTL0 |= SD16SC;                    // Set bit to start conversion

	while(1) {
		if(ADCReady) {
			Acc++;
			if(Acc == 8) {
				/* Average ADC */
				ActualTemp = GetTemp((ChA0Acc >> 3), (ChA6Acc >> 3));
				SetTemp = GetSetTemp(ChA1Acc >> 3);
				SetMotor = GetSetMotor(ChA2Acc >> 3);
				
				/* Regulator */
				Regulator();
				
				ChA0Acc = 0;
				ChA1Acc = 0;
				ChA2Acc = 0;
				ChA6Acc = 0;
				Acc = 0;
			}
			ADCReady = 0;							// Clear ADCReady flag
			SD16CCTL0 |= SD16SC;                    // Set bit to start conversion
		}

		/* Read Input, noise cancel */
		ReadKey();
                
		/* Reset WDT */
		WDTCTL = WDT_ARST_1000;
	}
}

/*
 * Init IO PINs
 */
void IOInit() {
	P2SEL &= ~BIT7;		// P2.7 General IO
	P2OUT &= ~BIT7;		// P2.7 -> 0
	P2DIR |= BIT7;		// P2.7 output

	P1SEL &= ~BIT5;		// P1.5 IO
	P1DIR &= ~BIT5;		// P1.5 input
	P1REN |= BIT5;		// R to Vcc
}

/*
 * Read Key
 */
void ReadKey() {
	DockAcc = DockAcc << 1;
	DockAcc |= !(DOCKPORT & DOCKPIN);
	if(DockAcc == 0xFFFF) Dock = 1;
	if(DockAcc == 0) Dock = 0;
}

/*
 * Convert ADC to SetTemp
 */
uint16_t GetSetTemp(uint16_t ADC) {
	uint16_t Temp = ADC / 88;
	if(Temp > 500) Temp = 500;
	return Temp;
}

/*
 * Convert ADC to SetMotor
 */
uint16_t GetSetMotor(uint16_t ADC) {
	uint16_t Motor = ADC / 440;
	if(Motor > 100) Motor = 100;
	return Motor;
}

/*
 * Get Temperature with compensation
 */
uint16_t GetTemp(uint16_t HotADC, uint16_t ColdADC) {
	uint16_t i;
	uint16_t HotTemp = 601;
	uint16_t ColdTemp = 25;
	/* Calculate HotSide Temp */
	for(i=0; i<TEMPCOUNT; i++) {
		if((HotADC >= TempTable[i]) && (HotADC < TempTable[i+1])) {
			HotTemp = i * TEMPSTEP + (HotADC - TempTable[i]) / 68;
		}
	}
	/* Calculate ColdSide Temp */
	for(i=0; i<INTTEMPCOUNT; i++) {
		if((ColdADC >= IntTempTable[i]) && (ColdADC < IntTempTable[i+1])) {
			ColdTemp = i;
		}
	}
	return (HotTemp + ColdTemp);
}

/*
 * The Regulator
 */
void Regulator() {
	if(Dock == 1) {
		if(ActualTemp < 50) {
			SetPWM(0);
		} 
		if (ActualTemp > 100) {
			SetPWM(100);
		}
		HEATOFF;
	} else {
		SetPWM(SetMotor);
		if(ActualTemp > SetTemp) {
			HEATOFF;
		}
		if(ActualTemp < SetTemp) {
			HEATON;
		}
	}
}

/*
 * 16-Bit ADC Interrupt
 */
#pragma vector = SD16_VECTOR
__interrupt void SD16ISR(void)
{
	switch (SD16IV)
	{
	case 2:									// SD16MEM Overflow
		break;
	case 4:									// SD16MEM0 IFG
		switch(Channel)
		{
		case 0:
			ChA0Acc += SD16MEM0;					// Save CH0 results (clears IFG)
			Channel++;
			SD16INCTL0 = SD16INCH_1;			// Enable channel A1+/-
			SD16AE = SD16AE2;					// Enable external input on A1+

			SD16CCTL0 |= SD16SC;				// Set bit to start conversion
			break;
		case 1:
			ChA1Acc += SD16MEM0;					// Save CH1 results (clears IFG)
			Channel++;
			SD16INCTL0 = SD16INCH_2;			// Enable channel A2+/-
			SD16AE = SD16AE4;					// Enable external input on A2+

			SD16CCTL0 |= SD16SC;				// Set bit to start conversion
			break;
		case 2:
			ChA2Acc += SD16MEM0;					// Save CH2 results (clears IFG)
			Channel++;
			SD16INCTL0 = SD16INCH_6;			// Enable channel A6+/-
			SD16AE = 0;

			SD16CCTL0 |= SD16SC;				// Set bit to start conversion
			break;
		case 3:
			ChA6Acc += SD16MEM0;					// Save CH6 results (clears IFG)
			Channel = 0;						// Reset channel count (end of seq)
			SD16INCTL0 = SD16INCH_0 + SD16GAIN_16;	// Set channel A0+/-, GAIN x16 (15.04)
			SD16AE = SD16AE0 + SD16AE1;				// Enable external input on A0+ A0-
			
			ADCReady = 1;						// Set Global Flag
			break;
		}
	}
}

