/*
 * clock.h
 *
 *  Created on: Apr 15, 2010
 *      Author: Pavel V. Gololobov
 */

#ifndef CLOCK_H_
#define CLOCK_H_

/*
 * Init Clock Sources
 */
void ClockInit() {
	BCSCTL1 = CALBC1_12MHZ;
	BCSCTL3 = LFXT1S_3;
	DCOCTL = CALDCO_12MHZ;
}

#endif /* CLOCK_H_ */
