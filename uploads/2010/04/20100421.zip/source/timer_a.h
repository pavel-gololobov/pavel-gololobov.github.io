/*
 * timer_a.h
 *
 *  Created on: Apr 15, 2010
 *      Author: Pavel V. Gololobov
 */

#ifndef TIMER_A_H_
#define TIMER_A_H_

/*
 * Init TimerA for PWM output
 */
void TAInit() {
	P2DIR |= BIT6;						// P2.6 output
	P2SEL |= BIT6;						// P2.6 TA1/2 options

	CCR0 = 100;							// PWM Period
	CCTL1 = OUTMOD_7;					// CCR1 reset/set
	CCR1 = 0;							// CCR1 PWM duty cycle
	TACTL = TASSEL_2 + MC_1;			// SMCLK, up mode
}

/*
 * Set PWM
 */
void SetPWM(uint16_t Value) {
	if(Value > 100) Value = 100;
	CCR1 = Value;
}

#endif /* TIMER_A_H_ */
