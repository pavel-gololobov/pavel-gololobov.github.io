/* 
 * main.h
 *
 *  Created on: Apr 14, 2010
 *      Author: Pavel V. Gololobov
 */

#ifndef MAIN_H_
#define MAIN_H_

/*
 * HEAT OUT
 */
#define HEATON		P2OUT |= BIT7
#define HEATOFF		P2OUT &= ~BIT7

/*
 * DOCK IN
 */
#define DOCKPORT	P1IN
#define DOCKPIN		BIT5


#endif /* MAIN_H_ */
