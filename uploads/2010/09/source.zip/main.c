/*
 * main.c
 *
 *  Created on: 12.09.2010
 *      Author:
 */

#include <msp430x16x.h>
#include <intrinsics.h>
#include <stdint.h>
#include "uart.h"
#include "tbcp.h"
#include "timers.h"
#include "main.h"

struct TTime Time;
struct TTime TimeAlarm;
struct TTime TimeStart;

uint32_t Log[2048];
uint16_t LogIndex = 0;

uint16_t XAxis = 0, XAxis_Prev = 0, XAxis_Delta = 0;
uint16_t YAxis = 0, YAxis_Prev = 0, YAxis_Delta = 0;
uint16_t Voltage = 0;

uint16_t AlarmWait = 0;
uint16_t Alarm = 0;
uint16_t LowBattery = 0;

void InitClock();
void InitPorts();
void InitADC();

int main(void) {
	// Stop watchdog timer to prevent time out reset
	WDTCTL = WDTPW + WDTHOLD;

	InitClock();
	InitPorts();
	InitADC();
	InitTimerA();
	InitTimerB();
	UARTA0_Init();

	__enable_interrupt();

	while(1) {
		if(BUTTON) {
			Alarm = 0;
			AlarmWait = 0;
			Process();
		} else {
			_BIS_SR(LPM0_bits);		// Enter LPM0
		}
	}
}

void InitClock() {
	BCSCTL1 = XT2OFF;
}

void InitPorts() {
	// Buzzer
	P1DIR |= BIT3;
	P1OUT &= ~BIT3;
	// Power of accelerometer
	P1DIR |= BIT4;
	P1OUT &= ~BIT4;
}

void InitADC() {
	P6SEL |= BIT6 + BIT7;

	ADC12CTL0 = ADC12ON + MSC + SHT0_3;
	ADC12CTL1 = SHP + CONSEQ_1;

	ADC12MCTL0 = INCH_6;
	ADC12MCTL1 = INCH_7;
	ADC12MCTL2 = INCH_11 + EOS;

	ADC12IE = 0x04;                           // Enable ADC12IFG.2
	ADC12CTL0 |= ENC;                         // Enable conversions
}

// Timer A0 interrupt service routine
#pragma vector=TIMERA0_VECTOR
__interrupt void Timer_A() {
	/*
	 * Time
	 */
	if(++Time.second == 60) {
		Time.second = 0;
		if(++Time.minute == 60) {
			Time.minute = 0;
			if(++Time.hour == 24) {
				Time.hour = 0;
			}
		}
	}

	/*
	 * Start Time
	 */
	if((Time.hour == TimeStart.hour) && (Time.minute == TimeStart.minute) && (Time.second == 0)) {
		AlarmWait = 1;
	}

	/*
	 * Alarm
	 */
	if (AlarmWait) {
		if((Time.hour == TimeAlarm.hour) && (Time.minute == TimeAlarm.minute) && (Time.second == 0)) {
			Alarm = 1;
		}
		if((XAxis_Delta + YAxis_Delta) > 100) {
			Alarm = 1;
		}
	}

	if(AlarmWait && Alarm) {
		BUZZER_TOGGLE;
	}
	ACC_ON;
	StartTimerB();
}

#pragma vector=TIMERB0_VECTOR
__interrupt void Timer_B() {
	TBCTL &=~ MC_2;				// Stop TimerB
	ADC12CTL0 |= ADC12SC;		// Start conversion
}

#pragma vector=ADC12_VECTOR
__interrupt void ADC12ISR() {
	XAxis = ADC12MEM0;
	YAxis = ADC12MEM1;
	Voltage = ADC12MEM2;

	ACC_OFF;

	if(XAxis > XAxis_Prev)
		XAxis_Delta = XAxis - XAxis_Prev;
	else
		XAxis_Delta = XAxis_Prev - XAxis;

	if(YAxis > YAxis_Prev)
		YAxis_Delta = YAxis - YAxis_Prev;
	else
		YAxis_Delta = YAxis_Prev - YAxis;

	XAxis_Prev = XAxis;
	YAxis_Prev = YAxis;

	_BIC_SR_IRQ(LPM0_bits);		// Clear LPM0 bits
}
