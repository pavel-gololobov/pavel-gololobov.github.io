/*
 * commands.h
 *
 *  Created on: 03.05.2010
 *      Author:
 */

#ifndef COMMANDS_H_
#define COMMANDS_H_

/*
 * BuildIn Commands
 */
#define CMD_NOP			0x00		// NOP
#define CMD_ERR			0x01		// RX Error
#define CMD_ECHO		0x02		// Echo
#define CMD_INFO		0x03		// Info
#define CMD_SETADDR		0x04		// Set Address
#define CMD_GETADDR		0x05		// Get Address

/*
 * Custom Commands
 */
#define CMD_GET_TIME	0x10
#define CMD_SET_TIME	0x11
#define CMD_GET_ALARM	0x20
#define CMD_SET_ALARM	0x21
#define CMD_GET_START	0x22
#define CMD_SET_START	0x23
#define CMD_GET_LOG		0x30


/*
 * Exe
 */
void Command_Exe(uint8_t ucCommand);

#endif /* COMMANDS_H_ */
