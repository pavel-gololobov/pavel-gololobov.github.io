/*
 * crc8.h
 *
 *  Created on: 03.05.2010
 *      Author:
 */

#ifndef CRC8_H_
#define CRC8_H_

#include <stdint.h>

uint8_t TBCP_CRC8(uint8_t *data, uint16_t num);

#endif /* CRC8_H_ */
