/*
 * commands.c
 *
 *  Created on: 03.05.2010
 *      Author:
 */

#include <stdint.h>
#include <intrinsics.h>
#include "main.h"
#include "tbcp.h"
#include "commands.h"

/*
 * Device Info String
 */
const uint8_t Info[] = {"Smart Alarm v0.1\0"};

/*
 * Error
 */
void CmdErr() {
	Reply(CMD_ERR, TBCP_EIO);
}

/*
 * Echo
 */
void CmdEcho() {
	uint16_t i;
	for(i = 0; i < RcvFrame[TBCP_LEN_INDEX] && i < TBCP_FRAME_SIZE; i++)
		SndFrame[i + TBCP_DATA_INDEX] = RcvFrame[i + TBCP_DATA_INDEX];
	Send(RcvFrame[TBCP_CMD_INDEX], RcvFrame[TBCP_LEN_INDEX]);
}

/*
 * Get Device Info
 */
void CmdInfo() {
	uint16_t i;
	uint8_t ch = 1;
	for(i = 0; i < TBCP_FRAME_SIZE && ch; i++)
		ch = SndFrame[i + TBCP_DATA_INDEX] = Info[i];
	Send(RcvFrame[TBCP_CMD_INDEX], i);
}

/*
 * Commant Not Implemented
 */
void CmdNotImplemented() {
	Reply(CMD_ERR, TBCP_ENOTIMPL);
}

void CmdGetTime() {
	struct TTime TimeNow;
	uint8_t	StateI;
	StateI = __get_interrupt_state();
	__disable_interrupt();
	TimeNow.second = Time.second;
	TimeNow.minute = Time.minute;
	TimeNow.hour = Time.hour;
	__set_interrupt_state(StateI);
	SndFrame[TBCP_DATA_INDEX] = TimeNow.hour;
	SndFrame[TBCP_DATA_INDEX + 1] = TimeNow.minute;
	SndFrame[TBCP_DATA_INDEX + 2] = TimeNow.second;
	Send(RcvFrame[TBCP_CMD_INDEX], 3);
}

void CmdSetTime() {
	struct TTime TimeNow;
	TimeNow.hour = RcvFrame[TBCP_DATA_INDEX];
	TimeNow.minute = RcvFrame[TBCP_DATA_INDEX + 1];
	TimeNow.second = RcvFrame[TBCP_DATA_INDEX + 2];
	uint8_t	StateI;
	StateI = __get_interrupt_state();
	__disable_interrupt();
	Time.second = TimeNow.second;
	Time.minute = TimeNow.minute;
	Time.hour = TimeNow.hour;
	__set_interrupt_state(StateI);
	Reply(RcvFrame[TBCP_CMD_INDEX], TBCP_ENOERR);
}

void CmdGetAlarm() {
	SndFrame[TBCP_DATA_INDEX] = TimeAlarm.hour;
	SndFrame[TBCP_DATA_INDEX + 1] = TimeAlarm.minute;
	SndFrame[TBCP_DATA_INDEX + 2] = TimeAlarm.second;
	Send(RcvFrame[TBCP_CMD_INDEX], 3);
}

void CmdSetAlarm() {
	TimeAlarm.hour = RcvFrame[TBCP_DATA_INDEX];
	TimeAlarm.minute = RcvFrame[TBCP_DATA_INDEX + 1];
	TimeAlarm.second = RcvFrame[TBCP_DATA_INDEX + 2];
	Reply(RcvFrame[TBCP_CMD_INDEX], TBCP_ENOERR);
}

void CmdGetStart() {
	SndFrame[TBCP_DATA_INDEX] = TimeStart.hour;
	SndFrame[TBCP_DATA_INDEX + 1] = TimeStart.minute;
	SndFrame[TBCP_DATA_INDEX + 2] = TimeStart.second;
	Send(RcvFrame[TBCP_CMD_INDEX], 3);
}

void CmdSetStart() {
	TimeStart.hour = RcvFrame[TBCP_DATA_INDEX];
	TimeStart.minute = RcvFrame[TBCP_DATA_INDEX + 1];
	TimeStart.second = RcvFrame[TBCP_DATA_INDEX + 2];
	Reply(RcvFrame[TBCP_CMD_INDEX], TBCP_ENOERR);
}

void CmdGetLog() {
	CmdNotImplemented();
}

/*
 * Commands Switch
 */
void Command_Exe(uint8_t ucCommand) {
	switch(ucCommand) {
		case CMD_NOP: {
			break;
		}
		case CMD_ERR: {
			CmdErr();
			break;
		}
		case CMD_ECHO: {
			CmdEcho();
			break;
		}
		case CMD_INFO: {
			CmdInfo();
			break;
		}
		case CMD_GET_TIME: {
			CmdGetTime();
			break;
		}
		case CMD_SET_TIME: {
			CmdSetTime();
			break;
		}
		case CMD_GET_ALARM: {
			CmdGetAlarm();
			break;
		}
		case CMD_SET_ALARM: {
			CmdSetAlarm();
			break;
		}
		case CMD_GET_START: {
			CmdGetStart();
			break;
		}
		case CMD_SET_START: {
			CmdSetStart();
			break;
		}
		case CMD_GET_LOG: {
			CmdGetLog();
			break;
		}
		default: {
			CmdNotImplemented();
			break;
		}
	}
}

