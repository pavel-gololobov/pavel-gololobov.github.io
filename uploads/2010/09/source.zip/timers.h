/*
 * timers.h
 *
 *  Created on: 13.09.2010
 *      Author:
 */

#ifndef TIMERS_H_
#define TIMERS_H_

void InitTimerA();
void InitTimerB();
void StartTimerB();

#endif /* TIMERS_H_ */
