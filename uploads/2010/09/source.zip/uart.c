/*
 * uart.c
 *
 *  Created on: 02.05.2010
 *      Author:
 */

#include <msp430x16x.h>
#include <stdio.h>
#include <stdint.h>
#include "uart.h"


/*
 * Init UARTA0 Port
 */
void UARTA0_Init(void) {
	P3OUT &= ~(BIT4 + BIT5);
	P3SEL |= BIT4 + BIT5;			// Enable UARTA0 pins

	ME1 |= UTXE0 + URXE0;           // Enable USART0 TXD/RXD
	UCTL0 |= CHAR;                  // 8-bit character
	UTCTL0 |= SSEL0;                // UCLK = ACLK

	UBR00 = 0x0D;                   // 32k/2400 - 13.65
	UBR10 = 0x00;                   //
	UMCTL0 = 0x6B;                  // Modulation

	UCTL0 &= ~SWRST;                // Initialize USART state machine
	IE1 |= URXIE0;                  // Enable USART0 RX interrupt
}

/*
 * Init UARTA1 Port
 */
//void UARTA1_Init(void) {
//	P3OUT &= ~(BIT6 + BIT7);
//	P3SEL |= BIT6 + BIT7;			// Enable UARTA1 pins
//
//	UCA1CTL0 |= UCSPB;			// 2 stop bits
//	UCA1CTL1 |= UCSSEL_2;			// SMCLK
//
//	UCA1BR0 = 0x60;
//	UCA1BR1 = 0;
//	UCA1MCTL = 0;					// uartA1 11059200Hz 115200bps
//
//	UCA1CTL1 &= ~UCSWRST;			// Initialize
//
//	UC1IE |= UCA1RXIE;				// Enable USCI_A1 RX interrupt
//}

