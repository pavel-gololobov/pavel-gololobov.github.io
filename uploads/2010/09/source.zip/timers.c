/*
 * timers.c
 *
 *  Created on: 13.09.2010
 *      Author:
 */

#include <msp430x16x.h>

#define ACC_DELAY	327

void InitTimerA() {
	TACCTL0 = CCIE;				// CCR0 interrupt enabled
	TACCR0 = 32768-1;			// 1 s
	TACTL = TASSEL_1 + MC_1;	// ACLK, upmode
}

void InitTimerB() {
	TBCCTL0 = CCIE;
	TBCCR0 = 0;
	TBCTL = TBSSEL_1;			// ACLK
}

void StartTimerB() {
	TBCCR0 += ACC_DELAY;		// Add Offset to CCR0
	TBCTL |= MC_2;
}
