/*
 * main.h
 *
 *  Created on: 12.09.2010
 *      Author:
 */

#ifndef MAIN_H_
#define MAIN_H_

#define BUZZER_ON		P1OUT |= BIT3
#define BUZZER_OFF		P1OUT &= ~BIT3
#define BUZZER_TOGGLE	P1OUT ^= BIT3;

#define ACC_ON		P1OUT |= BIT4
#define ACC_OFF		P1OUT &= ~BIT4

#define BUTTON		!(P5IN & 0x01)

struct TTime {
	uint8_t second;
	uint8_t minute;
	uint8_t hour;
};

extern struct TTime Time;
extern struct TTime TimeAlarm;
extern struct TTime TimeStart;

#endif /* MAIN_H_ */
