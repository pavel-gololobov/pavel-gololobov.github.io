/*
 * tbcp.h
 *
 *  Created on: 03.06.2010
 *      Author:
 */

#ifndef TBCP_H_
#define TBCP_H_

#include <stdint.h>

#define TBCP_FRAME_SIZE			128

#define TBCP_ADDR_INDEX			0
#define TBCP_CMD_INDEX			1
#define TBCP_LEN_INDEX			2
#define TBCP_DATA_INDEX			3
#define TBCP_MAX_DATA_LENGTH	TBCP_FRAME_SIZE - 4

typedef enum {
	TBCP_ENOERR,                  /*!< no error. */
	TBCP_ENOREG,                  /*!< illegal register address. */
	TBCP_EINVAL,                  /*!< illegal argument. */
	TBCP_EIO,                     /*!< I/O error. */
	TBCP_EILLSTATE,               /*!< protocol stack in illegal state. */
	TBCP_ETIMEDOUT,                /*!< timeout error occurred. */
	TBCP_ENOTIMPL,					/* Not Implemented */
	TBCP_EOVERFLOW
} eTBCPErrorCode;

extern uint8_t RcvFrame[TBCP_FRAME_SIZE];
extern uint8_t SndFrame[TBCP_FRAME_SIZE];

eTBCPErrorCode TBCP_Init(uint8_t ucSlaveAddress);
eTBCPErrorCode Process();
eTBCPErrorCode Send(uint8_t ucCommand, uint8_t ucLength);
eTBCPErrorCode Reply(uint8_t ucCommand, uint8_t ucErrorCode);

#endif /* TBCP_H_ */
