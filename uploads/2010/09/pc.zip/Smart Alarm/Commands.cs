﻿namespace Smart_Alarm
{
    public struct Commands
    {
        /*
         * Standart Cmds
         */
        public const byte CMD_NOP =        0x00;		// NOP
        public const byte CMD_ERR =        0x01;		// RX Error
        public const byte CMD_ECHO =       0x02;		// Echo
        public const byte CMD_INFO =       0x03;		// Info
        public const byte CMD_SETADDR =    0x04;		// Set Address
        public const byte CMD_GETADDR =    0x05;		// Get Address
    }
}