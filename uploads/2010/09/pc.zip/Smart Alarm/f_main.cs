﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Smart_Alarm {
    public partial class FMain : Form {
        CIOBoard IOBoard;

        public FMain() {
            InitializeComponent();
            string[] lPorts = System.IO.Ports.SerialPort.GetPortNames();
            foreach(string sPort in lPorts) {
                comboBox1.Items.Add(sPort);
            }
        }

        private void button1_Click(object sender, EventArgs e) {

        }

        private void button3_Click(object sender, EventArgs e) {

        }

        private void button5_Click(object sender, EventArgs e) {

        }

        private void button2_Click(object sender, EventArgs e) {

        }

        private void button4_Click(object sender, EventArgs e) {

        }

        private void button6_Click(object sender, EventArgs e) {

        }

        public void SetTime(int Hour, int Minute) {
        }

        public void SetStart(int Hour, int Minute) {
        }

        public void SetAlarm(int Hour, int Minute) {
        }

        private void button7_Click(object sender, EventArgs e) {
            try {
                IOBoard = new CIOBoard(this, comboBox1.SelectedItem.ToString());
            } catch(Exception Ex) {
                MessageBox.Show(Ex.Message);
            }
            button8.Enabled = true;
        }

        private void button8_Click(object sender, EventArgs e) {
            IOBoard.Send(Convert.ToByte(textBox1.Text, 16), textBox2.Text);
        }

        public void AddText(string text) {
            if(textBox3.InvokeRequired) {
                textBox3.BeginInvoke(
                    new MethodInvoker(
                    delegate() { AddText(text); }));
            } else {
                textBox3.Text = text;
            }
        }
    }
}
