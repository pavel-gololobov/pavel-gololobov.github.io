﻿using System;
using System.Text;
using System.Drawing;
using System.IO.Ports;
using System.Windows.Forms;
using System.Threading;

namespace Smart_Alarm {
    class CPort {
        public delegate void HandleDelegate(string Str);

        #region Variables
        private string _baudRate;
        private string _parity;
        private string _stopBits;
        private string _dataBits;
        private string _portName;
        private int _portTimeout;

        private HandleDelegate _messageHandler;
        private static SerialPort _comPort = new SerialPort();
        #endregion

        #region Manager Properties
        /// <summary>
        /// Property to hold the BaudRate
        /// of our manager class
        /// </summary>
        public string BaudRate {
            get { return _baudRate; }
            set { _baudRate = value; }
        }

        /// <summary>
        /// property to hold the Parity
        /// of our manager class
        /// </summary>
        public string Parity {
            get { return _parity; }
            set { _parity = value; }
        }

        /// <summary>
        /// property to hold the StopBits
        /// of our manager class
        /// </summary>
        public string StopBits {
            get { return _stopBits; }
            set { _stopBits = value; }
        }

        /// <summary>
        /// property to hold the DataBits
        /// of our manager class
        /// </summary>
        public string DataBits {
            get { return _dataBits; }
            set { _dataBits = value; }
        }

        /// <summary>
        /// property to hold the PortName
        /// of our manager class
        /// </summary>
        public string PortName {
            get { return _portName; }
            set { _portName = value; }
        }

        /// <summary>
        /// Port Timeout
        /// </summary>
        public int Timeout {
            get { return _portTimeout; }
            set { _portTimeout = value; }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="baud">Baudrate</param>
        /// <param name="par">Parity</param>
        /// <param name="sBits">Stop Bits</param>
        /// <param name="dBits">Data Bits</param>
        /// <param name="name">Port Name</param>
        /// <param name="timeout">Timeout (ms)</param>
        /// <param name="handler">Message Handler</param>
        public CPort(string baud, string par, string sBits, string dBits, string name, 
                int timeout, HandleDelegate handler) {
            _baudRate = baud;
            _parity = par;
            _stopBits = sBits;
            _dataBits = dBits;
            _portName = name;
            _portTimeout = timeout;
            _messageHandler = handler;

            _comPort.DataReceived += new SerialDataReceivedEventHandler(DataReceived);
        }
        #endregion

        #region Open/Close Port
        /// <summary>
        /// Open Port
        /// </summary>
        public void OpenPort() {
            try {
                if (_comPort.IsOpen) _comPort.Close();
                //set the properties of our SerialPort Object
                _comPort.BaudRate = int.Parse(_baudRate);    //BaudRate
                _comPort.DataBits = int.Parse(_dataBits);    //DataBits
                _comPort.StopBits = (StopBits)Enum.Parse(typeof(StopBits), _stopBits);    //StopBits
                _comPort.Parity = (Parity)Enum.Parse(typeof(Parity), _parity);    //Parity
                _comPort.PortName = _portName;   //PortName
                // Set the read/write timeouts
                _comPort.ReadTimeout = _portTimeout;
                _comPort.WriteTimeout = _portTimeout;
                // now open the port
                _comPort.Open();
            } catch (Exception ex) {
                throw ex;
            }
        }
        /// <summary>
        /// Close Port
        /// </summary>
        public void ClosePort() {
            try {
                if(_comPort.IsOpen) _comPort.Close();
            } catch(Exception ex) {
                throw ex;
            }
        }
        #endregion

        #region WriteData
        /// <summary>
        /// Write Message to Port
        /// </summary>
        /// <param name="msg"></param>
        public void WriteData(string Message) {
            try {
                if (!_comPort.IsOpen) OpenPort();
                byte[] asciiBytes = Encoding.ASCII.GetBytes(Message);
                _comPort.Write(asciiBytes, 0, asciiBytes.Length);
            } catch (Exception ex) {
                throw ex;
            }
        }
        #endregion

        #region DataReceived Handler
        /// <summary>
        /// method that will be called when theres data waiting in the buffer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataReceived(object sender, SerialDataReceivedEventArgs e) {
            try {
                string msg = _comPort.ReadLine();
                _messageHandler(msg);
            } catch (TimeoutException) { 
                // NOP
            } catch (Exception ex) {
                throw ex;
            }
        }
        #endregion
    }
}